SELECT COUNT(DISTINCT creditLimit) AS numLimits from customers;
