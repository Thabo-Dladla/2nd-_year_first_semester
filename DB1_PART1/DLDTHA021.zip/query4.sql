SELECT * FROM orderdetails WHERE quantityOrdered*priceEach>10000;
