SELECT * FROM offices;
