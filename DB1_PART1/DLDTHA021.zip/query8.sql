SELECT COUNT(employeeNumber) AS numEmps FROM employees;
