SELECT city,phone FROM offices ORDER BY city ASC,phone DESC;
