SELECT * FROM offices WHERE country = 'UK' OR country = 'SA';
