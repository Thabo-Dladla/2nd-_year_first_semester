SELECT ROUND(AVG(buyPrice),2) AS avPrice FROM products;
